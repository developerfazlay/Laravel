<?php

namespace App\Http\Controllers\Admin;

use App\Models\Blog;
use App\Models\BlogCategory;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Intervention\Image\Facades\Image;
use Illuminate\Support\Facades\Validator;

class BlogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
     {   
      // always use the inner join
        $data['blogs'] = Blog::join('blog_categories', 'blog_categories.id', '=', 'blogs.category_id')->select('blogs.*', 'blog_categories.name as catName')->orderBy('blogs.created_at', 'desc')->get();
        return view('admin.blog.listData', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {   
        $data['blogCategories'] = BlogCategory::get()->where('valid','=',1)->sortBy('name');
        // $data['blogCategories'] = BlogCategory::get()->where('valid','=',1)->sortDesc();
        return view('admin.blog.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
          $validator = Validator::make($request->all(), [
            'category_id'  => 'required',
            'title'        => 'required',
            'valid'        => 'required',
            'thumbnail'    => 'image|mimes:jpeg,png,jpg|max:500',
           ]);
           
           
          if ($validator->passes()) {

            
            // If blogthumb available
            if ($request->thumbnail) {
              $mainFile       =  $request->thumbnail; 
              $fileUniqueName = 'img'.date('dmY').'_'.time().'.'.$mainFile->getClientOriginalExtension();
 
              $thumbDestinationPath     = public_path('uploads/blogs/resizedThumbs');  
              
             // Make Resize image with add composer require intervention/image and add few code on config/app.php with server php.ini file image extension without comment
              $interventionImg     = Image::make($mainFile->getRealPath());
              $interventionImg->resize(300, 300)->save($thumbDestinationPath.'/'.$fileUniqueName);
             //  function ($constraint) {
             //   $constraint->aspectRatio();
             // }) This will call beside the height as 3rd argument if we want to crop the image according ratio
              $mainDestinationPath = public_path('uploads/blogs/blogMainImages'); 
              $mainFile ->move($mainDestinationPath, $fileUniqueName);
 
             //  $size = $mainFile->getSize();
             
             // Need to configure the following Model as $fillable array with this fields
             
             Blog::create(
               ['category_id'     => $request -> category_id,
               'title'            => $request -> title,
               'subtitle'         => $request -> subtitle,
               'description'      => $request -> description,
               'thumbnail'        => $fileUniqueName,
               'valid'            => $request->valid
               ]
             );
            } 
            else {
              Blog::create(
                ['category_id'     => $request -> category_id,
                'title'            => $request -> title,
                'subtitle'         => $request -> subtitle,
                'description'      => $request -> description,
                'valid'            => $request->valid
                // 'thumbnail'        => $fileUniqueName,
                ]
              );
            }
            // without blog thumb
            
             
            
          Toastr::success('Successfully Blog Created', 'Success!');
          
          }
          
          else {
            $err_msgs = $validator->messages();
            foreach ($err_msgs->all() as $key => $msg) {
              Toastr::error($msg, 'Required !');
            }
            
          }
          
          return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      // $userdata =  User::where('id', '=', $id)->first();
     $dataCat['blogCategories'] = BlogCategory::get()->where('valid','=',1)->sortBy('name');
     $data['blogs'] = Blog::find($id);
    
     return view("admin.blog.update", $data, $dataCat);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       
      $validator = Validator::make($request->all(), [
        'category_id'  => 'required',
        'title'        => 'required',
        'valid'        => 'required',
        'thumbnail'    => 'image|mimes:jpeg,png,jpg|max:500',
       ]);
       
       
      if ($validator->passes()) {

        
        // If blogthumb available
        if ($request->thumbnail) {
          $mainFile       =  $request->thumbnail; 
          $fileUniqueName = 'img'.date('dmY').'_'.time().'.'.$mainFile->getClientOriginalExtension();

          $thumbDestinationPath     = public_path('uploads/blogs/resizedThumbs');  
          
         // Make Resize image with add composer require intervention/image and add few code on config/app.php with server php.ini file image extension without comment
          $interventionImg     = Image::make($mainFile->getRealPath());
          $interventionImg->resize(300, 300)->save($thumbDestinationPath.'/'.$fileUniqueName);
         //  function ($constraint) {
         //   $constraint->aspectRatio();
         // }) This will call beside the height as 3rd argument if we want to crop the image according ratio
          $mainDestinationPath = public_path('uploads/blogs/blogMainImages'); 
          $mainFile ->move($mainDestinationPath, $fileUniqueName);

         //  $size = $mainFile->getSize();
         
         // Need to configure the following Model as $fillable array with this fields
         Blog::find($id)->update([
          'category_id'       => $request -> category_id,
           'title'            => $request -> title,
           'subtitle'         => $request -> subtitle,
           'description'      => $request -> description,
           'thumbnail'        => $fileUniqueName,
           'valid'            => $request->valid
          ]);
         
        } 
        else {

        Blog::find($id)->update([
            'category_id'        => $request -> category_id,
            'title'            => $request -> title,
            'subtitle'         => $request -> subtitle,
            'description'      => $request -> description,
            'valid'            => $request->valid
          ]);   

        }
        // without blog thumb
        
         
        
      Toastr::success('Successfully Blog Updated', 'Success!');
      
      }
      
      else {
        $err_msgs = $validator->messages();
        foreach ($err_msgs->all() as $key => $msg) {
          Toastr::error($msg, 'Required !');
        }
        
      }
      
      return redirect()->back();  
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
      
      Blog::find($id)->update([
        'valid'     => 0,
        ]);

      // $data = Blog::find($id);

      // dd($data);

      // Blog::find($id)->delete();
      return redirect()->back();  
    }
}
