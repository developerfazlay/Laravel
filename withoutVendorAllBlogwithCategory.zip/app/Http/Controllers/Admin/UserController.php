<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class UserController extends Controller
{
    public function index(){
        
      $data['users'] = User::get();
      return view('admin.user.listData', $data);
    }

    // Create form
    public function create(){
        return view('admin.user.create');
    }
 
    // Data save on db
    public function store(Request $request){

      $validator = Validator::make($request->all(), [
        'name'  => 'required',
        'email' => 'required|email'
      ]);

      // $password = Hash::make('password');


      if ($validator->passes()) {
        User::create(
          ['name'     => $request -> name,
          'email'     => $request -> email,
          'password'  => Hash::make($request->password),    
          ]
        );
      Toastr::success('User Registration Successful', 'Success!');
      
      }
      else {
        $err_msgs = $validator->messages();
        foreach ($err_msgs->all() as $key => $msg) {
          Toastr::error($msg, 'Required !');
        }
        
      }
      
      return redirect()->back();

    }



    // Database update 

    // View updating data
    public function edit($ids){
     
    // $userdata =  User::where('id', '=', $id)->first();
     $data['userinfo'] = User::find($ids);
    
     return view("admin.user.update", $data);
    }


    // update method
    public function update(Request $request, $id){

      $validator = Validator::make($request->all(), [
        'name'  => 'required',
        'email' => 'required|email'
      ]);

      if ($validator->passes()) {
        User::find($id)->update([
          'name'      => $request -> name,
          'email'     => $request -> email,
          'password'  => $request ->password,    
           
        ]);
      Toastr::success('Successfully User Updated .', 'Success !');
      }

      else {
        $err_msgs = $validator->messages();
        foreach ($err_msgs->all() as $key => $msg) {
          Toastr::error($msg, 'Required !');
        }
      }
      
      return redirect()->back();
    }


    // delete method
    public function destroy($del_id){
      User::find($del_id)->delete();
      Toastr::success('Successfully User Deleted .', 'Success !');
      return redirect()->back();
    }













}
